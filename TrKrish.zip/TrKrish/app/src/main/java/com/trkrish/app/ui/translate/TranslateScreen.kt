package com.trkrish.app.ui.translate

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.trkrish.app.ui.components.*

@Composable
fun TranslateScreen(vm: TranslateViewModel, snackbar: SnackbarHostState) {
    val s by vm.state.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(s.message) {
        s.message?.let { snackbar.showSnackbar(it); vm.dismissMessage() }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        LanguageBar(s.source, s.target, vm.languages, vm::onSource, vm::onTarget, vm::swap)

        TextCard(
            title = s.source.name,
            actions = {
                SpeakerButton(enabled = s.input.isNotBlank()) { vm.speak(s.input, s.source) }
                if (s.input.isNotEmpty()) {
                    IconButton(onClick = vm::clearInput) {
                        Icon(Icons.Default.Close, contentDescription = "Clear")
                    }
                }
            },
        ) {
            PlainTextField(s.input, vm::onInput, "Type or paste text here")
        }

        PrimaryButton("Translate", loading = s.isLoading, enabled = s.input.isNotBlank(), onClick = vm::translate)

        TextCard(
            title = s.target.name,
            actions = {
                SpeakerButton(enabled = s.output.isNotBlank()) { vm.speak(s.output, s.target) }
                IconButton(
                    onClick = { clipboard.setText(AnnotatedString(s.output)) },
                    enabled = s.output.isNotBlank(),
                ) { Icon(Icons.Default.ContentCopy, contentDescription = "Copy") }
            },
        ) {
            Text(
                text = s.output.ifEmpty { "Your translation will appear here" },
                style = MaterialTheme.typography.bodyLarge,
                color = if (s.output.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant
                else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.heightIn(min = 80.dp),
            )
        }
    }
}
