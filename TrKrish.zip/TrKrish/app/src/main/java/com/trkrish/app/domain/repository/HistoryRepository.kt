package com.trkrish.app.domain.repository

import com.trkrish.app.domain.model.HistoryItem
import kotlinx.coroutines.flow.StateFlow

interface HistoryRepository {
    val items: StateFlow<List<HistoryItem>>
    fun add(item: HistoryItem)
    fun delete(id: Long)
    fun clear()
}
