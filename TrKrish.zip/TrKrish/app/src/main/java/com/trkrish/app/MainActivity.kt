package com.trkrish.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.trkrish.app.ui.TrKrishApp
import com.trkrish.app.ui.theme.TrKrishTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as TrKrishApplication).container
        setContent { TrKrishTheme { TrKrishApp(container) } }
    }
}
