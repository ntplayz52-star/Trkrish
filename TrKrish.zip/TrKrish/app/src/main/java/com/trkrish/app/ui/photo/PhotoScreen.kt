package com.trkrish.app.ui.photo

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.trkrish.app.ui.components.*

@Composable
fun PhotoScreen(vm: PhotoViewModel, snackbar: SnackbarHostState) {
    val s by vm.state.collectAsStateWithLifecycle()

    LaunchedEffect(s.message) {
        s.message?.let { snackbar.showSnackbar(it); vm.dismissMessage() }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.onImagePicked(uri)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        LanguageBar(s.source, s.target, vm.languages, vm::onSource, vm::onTarget, vm::swap)

        TextCard(title = "Photo") {
            if (s.imageUri != null) {
                AsyncImage(
                    model = s.imageUri,
                    contentDescription = "Selected photo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp).clip(RoundedCornerShape(12.dp)),
                )
                Spacer(Modifier.height(12.dp))
            }
            FilledTonalButton(
                onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Default.Image, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (s.imageUri == null) "Choose a photo" else "Choose another photo")
            }
        }

        TextCard(
            title = "Text found in photo",
            actions = { SpeakerButton(s.extracted.isNotBlank()) { vm.speak(s.extracted, s.source) } },
        ) {
            if (s.isReading) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("Reading text…")
                }
            } else {
                PlainTextField(s.extracted, vm::onExtractedEdit, "Text from your photo appears here")
            }
        }

        PrimaryButton("Translate", loading = s.isTranslating, enabled = s.extracted.isNotBlank(), onClick = vm::translate)

        TextCard(
            title = s.target.name,
            actions = { SpeakerButton(s.translated.isNotBlank()) { vm.speak(s.translated, s.target) } },
        ) {
            Text(
                text = s.translated.ifEmpty { "Your translation will appear here" },
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.heightIn(min = 60.dp),
            )
        }
    }
}
