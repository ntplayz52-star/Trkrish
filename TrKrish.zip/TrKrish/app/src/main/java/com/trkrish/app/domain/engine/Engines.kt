package com.trkrish.app.domain.engine

import android.graphics.Bitmap
import com.trkrish.app.domain.model.Language

/** Every engine answers with either Success or Failure (with a readable message). */
sealed interface Outcome<out T> {
    data class Success<out T>(val value: T) : Outcome<T>
    data class Failure(val message: String) : Outcome<Nothing>
}

/** Anything that can translate text. Swap the implementation to change the engine. */
interface TranslationEngine {
    suspend fun translate(text: String, from: Language, to: Language): Outcome<String>
}

/** Anything that can read text out of a photo (OCR). */
interface TextRecognizer {
    suspend fun extractText(image: Bitmap): Outcome<String>
}

/** Anything that can read text aloud. */
interface SpeechEngine {
    fun speak(text: String, language: Language): Outcome<Unit>
    fun stop()
}
