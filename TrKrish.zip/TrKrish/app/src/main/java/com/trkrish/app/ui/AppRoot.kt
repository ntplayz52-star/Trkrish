package com.trkrish.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.trkrish.app.TrKrishApp
import com.trkrish.app.ui.screens.HistoryScreen
import com.trkrish.app.ui.screens.PhotoScreen
import com.trkrish.app.ui.screens.TranslateScreen
import com.trkrish.app.ui.viewmodel.HistoryViewModel
import com.trkrish.app.ui.viewmodel.PhotoViewModel
import com.trkrish.app.ui.viewmodel.TranslateViewModel
import com.trkrish.app.ui.viewmodel.ViewModelFactory

enum class Destination(val route: String, val label: String, val icon: ImageVector) {
    Translate("translate", "Translate", Icons.Filled.Translate),
    Photo("photo", "Photo", Icons.Filled.PhotoCamera),
    History("history", "History", Icons.Filled.History),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    val context = LocalContext.current
    val container = (context.applicationContext as TrKrishApp).container
    val factory = remember { ViewModelFactory(container) }
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("TrKrish") }) },
        bottomBar = {
            NavigationBar {
                Destination.entries.forEach { destination ->
                    NavigationBarItem(
                        selected = currentRoute == destination.route,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(destination.icon, contentDescription = null) },
                        label = { Text(destination.label) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Destination.Translate.route,
            modifier = Modifier.padding(padding),
        ) {
            composable(Destination.Translate.route) {
                TranslateScreen(viewModel<TranslateViewModel>(factory = factory))
            }
            composable(Destination.Photo.route) {
                PhotoScreen(viewModel<PhotoViewModel>(factory = factory))
            }
            composable(Destination.History.route) {
                HistoryScreen(viewModel<HistoryViewModel>(factory = factory))
            }
        }
    }
}
