package com.trkrish.app.ui.viewmodel

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trkrish.app.domain.engine.Outcome
import com.trkrish.app.domain.engine.SpeechEngine
import com.trkrish.app.domain.engine.TextRecognizer
import com.trkrish.app.domain.engine.TranslationEngine
import com.trkrish.app.domain.model.HistoryItem
import com.trkrish.app.domain.model.Language
import com.trkrish.app.domain.model.Languages
import com.trkrish.app.domain.repository.HistoryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PhotoUiState(
    val image: Bitmap? = null,
    val extractedText: String = "",
    val translatedText: String = "",
    val source: Language = Languages.AutoDetect,
    val target: Language = Languages.English,
    val isExtracting: Boolean = false,
    val isTranslating: Boolean = false,
    val error: String? = null,
)

class PhotoViewModel(
    private val engine: TranslationEngine,
    private val ocr: TextRecognizer,
    private val speech: SpeechEngine,
    private val history: HistoryRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(PhotoUiState())
    val state: StateFlow<PhotoUiState> = _state.asStateFlow()

    fun onImagePicked(bitmap: Bitmap) = _state.update {
        it.copy(image = bitmap, extractedText = "", translatedText = "", error = null)
    }
    fun onExtractedTextChange(text: String) = _state.update { it.copy(extractedText = text, error = null) }
    fun setSource(language: Language) = _state.update { it.copy(source = language) }
    fun setTarget(language: Language) = _state.update { it.copy(target = language) }

    fun swapLanguages() = _state.update { s ->
        if (s.source.isAuto) s else s.copy(source = s.target, target = s.source)
    }

    fun extractText() {
        val image = _state.value.image ?: return
        if (_state.value.isExtracting) return
        _state.update { it.copy(isExtracting = true, error = null) }
        viewModelScope.launch {
            when (val result = ocr.extractText(image)) {
                is Outcome.Success ->
                    _state.update { it.copy(isExtracting = false, extractedText = result.value, translatedText = "") }
                is Outcome.Failure ->
                    _state.update { it.copy(isExtracting = false, error = result.message) }
            }
        }
    }

    fun translate() {
        val s = _state.value
        if (s.extractedText.isBlank() || s.isTranslating) return
        _state.update { it.copy(isTranslating = true, error = null) }
        viewModelScope.launch {
            when (val result = engine.translate(s.extractedText.trim(), s.source, s.target)) {
                is Outcome.Success -> {
                    val now = System.currentTimeMillis()
                    history.add(HistoryItem(now, s.extractedText.trim(), result.value, s.source, s.target, now))
                    _state.update { it.copy(isTranslating = false, translatedText = result.value) }
                }
                is Outcome.Failure ->
                    _state.update { it.copy(isTranslating = false, translatedText = "", error = result.message) }
            }
        }
    }

    fun speak(text: String, language: Language) {
        if (text.isBlank()) return
        val result = speech.speak(text, language)
        if (result is Outcome.Failure) _state.update { it.copy(error = result.message) }
    }

    override fun onCleared() = speech.stop()
}
