package com.trkrish.app.data

import android.net.Uri
import com.trkrish.app.domain.*

/**
 * Honest placeholders: they never invent results, they just say "not connected".
 * In the next step we replace each one with a real engine.
 */
class NotConnectedTranslationEngine : TranslationEngine {
    override val supportedLanguages: List<Language> = Languages.default
    override suspend fun translate(text: String, source: Language, target: Language): Result<String> =
        Result.failure(EngineNotConnectedException("The translation engine"))
}

class NotConnectedTextRecognizer : TextRecognizer {
    override suspend fun recognize(imageUri: Uri): Result<String> =
        Result.failure(EngineNotConnectedException("Text recognition (OCR)"))
}

class NotConnectedSpeechEngine : SpeechEngine {
    override fun speak(text: String, language: Language): Result<Unit> =
        Result.failure(EngineNotConnectedException("Text-to-speech"))
}
