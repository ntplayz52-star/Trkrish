package com.trkrish.app.domain

/** Translates text and, only if it really worked, saves it to history. */
class TranslateAndSaveUseCase(
    private val engine: TranslationEngine,
    private val history: HistoryRepository,
) {
    suspend operator fun invoke(text: String, source: Language, target: Language): Result<String> =
        engine.translate(text.trim(), source, target).onSuccess { result ->
            history.add(TranslationRecord(System.currentTimeMillis(), text.trim(), result, source, target))
        }
}
