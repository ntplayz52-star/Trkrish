package com.trkrish.app.domain

import android.net.Uri
import kotlinx.coroutines.flow.StateFlow

/** The ONLY things the screens know about. Swap the implementations in AppContainer. */
interface TranslationEngine {
    val supportedLanguages: List<Language>
    suspend fun translate(text: String, source: Language, target: Language): Result<String>
}

interface TextRecognizer {
    suspend fun recognize(imageUri: Uri): Result<String>
}

interface SpeechEngine {
    fun speak(text: String, language: Language): Result<Unit>
}

interface HistoryRepository {
    val items: StateFlow<List<TranslationRecord>>
    fun add(record: TranslationRecord)
    fun delete(id: Long)
    fun clear()
}

class EngineNotConnectedException(what: String) :
    Exception("$what is not connected yet. We will connect it in the next step.")

fun Throwable.userMessage(): String = message ?: "Something went wrong. Please try again."
