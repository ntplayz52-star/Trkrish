package com.trkrish.app.domain

data class Language(val code: String, val name: String)

object Languages {
    val default = listOf(
        Language("en", "English"), Language("hi", "Hindi"), Language("bn", "Bengali"),
        Language("ta", "Tamil"), Language("te", "Telugu"), Language("mr", "Marathi"),
        Language("gu", "Gujarati"), Language("ur", "Urdu"), Language("es", "Spanish"),
        Language("fr", "French"), Language("de", "German"), Language("ja", "Japanese"),
    )
}

data class TranslationRecord(
    val id: Long,
    val sourceText: String,
    val translatedText: String,
    val source: Language,
    val target: Language,
)
