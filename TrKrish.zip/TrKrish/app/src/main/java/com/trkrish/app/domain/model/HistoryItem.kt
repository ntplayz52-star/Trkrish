package com.trkrish.app.domain.model

data class HistoryItem(
    val id: Long,
    val sourceText: String,
    val translatedText: String,
    val source: Language,
    val target: Language,
    val timestamp: Long,
)
