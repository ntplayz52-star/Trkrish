package com.trkrish.app

import android.app.Application
import com.trkrish.app.data.*
import com.trkrish.app.domain.*

/** One place that decides WHICH engine the app uses. Change engines here only. */
class AppContainer {
    val translationEngine: TranslationEngine = NotConnectedTranslationEngine()
    val textRecognizer: TextRecognizer = NotConnectedTextRecognizer()
    val speechEngine: SpeechEngine = NotConnectedSpeechEngine()
    val history: HistoryRepository = InMemoryHistoryRepository()
    val translateAndSave = TranslateAndSaveUseCase(translationEngine, history)
}

class TrKrishApplication : Application() {
    val container by lazy { AppContainer() }
}
