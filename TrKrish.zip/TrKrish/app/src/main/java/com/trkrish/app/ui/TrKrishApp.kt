package com.trkrish.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import com.trkrish.app.AppContainer
import com.trkrish.app.ui.history.HistoryScreen
import com.trkrish.app.ui.history.HistoryViewModel
import com.trkrish.app.ui.photo.PhotoScreen
import com.trkrish.app.ui.photo.PhotoViewModel
import com.trkrish.app.ui.translate.TranslateScreen
import com.trkrish.app.ui.translate.TranslateViewModel

enum class Tab(val label: String, val icon: ImageVector) {
    Translate("Translate", Icons.Default.Translate),
    Photo("Photo", Icons.Default.PhotoCamera),
    History("History", Icons.Default.History),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrKrishApp(container: AppContainer) {
    val factory = remember { VmFactory(container) }
    val translateVm: TranslateViewModel = viewModel(factory = factory)
    val photoVm: PhotoViewModel = viewModel(factory = factory)
    val historyVm: HistoryViewModel = viewModel(factory = factory)

    var tab by rememberSaveable { mutableStateOf(Tab.Translate) }
    val snackbar = remember { SnackbarHostState() }

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("TrKrish") }) },
        bottomBar = {
            NavigationBar {
                Tab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) },
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                Tab.Translate -> TranslateScreen(translateVm, snackbar)
                Tab.Photo -> PhotoScreen(photoVm, snackbar)
                Tab.History -> HistoryScreen(historyVm, snackbar)
            }
        }
    }
}
