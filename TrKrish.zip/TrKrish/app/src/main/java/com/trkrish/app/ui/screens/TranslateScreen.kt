package com.trkrish.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.trkrish.app.ui.components.ErrorBanner
import com.trkrish.app.ui.components.LanguageBar
import com.trkrish.app.ui.components.LoadingButton
import com.trkrish.app.ui.components.ResultCard
import com.trkrish.app.ui.components.SpeakerButton
import com.trkrish.app.ui.viewmodel.TranslateViewModel

@Composable
fun TranslateScreen(viewModel: TranslateViewModel, modifier: Modifier = Modifier) {
    val state by viewModel.state.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        LanguageBar(
            source = state.source,
            target = state.target,
            onSourceChange = viewModel::setSource,
            onTargetChange = viewModel::setTarget,
            onSwap = viewModel::swapLanguages,
        )

        OutlinedTextField(
            value = state.input,
            onValueChange = viewModel::onInputChange,
            modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
            label = { Text("Type text to translate") },
        )

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { viewModel.onInputChange("") }, enabled = state.input.isNotEmpty()) {
                Text("Clear")
            }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                SpeakerButton(
                    onClick = { viewModel.speak(state.input, state.source) },
                    enabled = state.input.isNotBlank(),
                )
            }
        }

        LoadingButton(
            text = "Translate",
            onClick = viewModel::translate,
            isLoading = state.isLoading,
            enabled = state.input.isNotBlank(),
        )

        state.error?.let { ErrorBanner(it) }

        if (state.output.isNotBlank()) {
            ResultCard(
                title = state.target.name,
                text = state.output,
                onSpeak = { viewModel.speak(state.output, state.target) },
            )
        }
    }
}
