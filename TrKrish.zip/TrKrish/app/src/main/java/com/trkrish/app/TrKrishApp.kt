package com.trkrish.app

import android.app.Application

class TrKrishApp : Application() {
    val container = AppContainer()
}
