package com.trkrish.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.trkrish.app.AppContainer

/** Builds each ViewModel and hands it the engines it needs. */
class ViewModelFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(TranslateViewModel::class.java) ->
            TranslateViewModel(c.translationEngine, c.speechEngine, c.history) as T
        modelClass.isAssignableFrom(PhotoViewModel::class.java) ->
            PhotoViewModel(c.translationEngine, c.textRecognizer, c.speechEngine, c.history) as T
        modelClass.isAssignableFrom(HistoryViewModel::class.java) ->
            HistoryViewModel(c.history) as T
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    }
}
