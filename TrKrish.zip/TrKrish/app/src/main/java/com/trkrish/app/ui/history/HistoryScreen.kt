package com.trkrish.app.ui.history

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.trkrish.app.ui.components.SpeakerButton
import com.trkrish.app.ui.components.TextCard

@Composable
fun HistoryScreen(vm: HistoryViewModel, snackbar: SnackbarHostState) {
    val items by vm.items.collectAsStateWithLifecycle()
    var note by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(note) { note?.let { snackbar.showSnackbar(it); note = null } }

    if (items.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                "No translations yet.\nYour past translations will show up here.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("History", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(onClick = vm::clearAll) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Clear all")
                }
            }
        }
        items(items, key = { it.id }) { r ->
            TextCard(
                title = "${r.source.name} → ${r.target.name}",
                actions = {
                    SpeakerButton(true) { vm.speak(r.translatedText, r.target).onFailure { note = it.message } }
                    IconButton(onClick = { vm.delete(r.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete")
                    }
                },
            ) {
                Text(r.sourceText, style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Text(r.translatedText, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}
