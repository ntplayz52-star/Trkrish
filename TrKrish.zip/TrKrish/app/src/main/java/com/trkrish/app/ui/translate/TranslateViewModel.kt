package com.trkrish.app.ui.translate

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trkrish.app.AppContainer
import com.trkrish.app.domain.Language
import com.trkrish.app.domain.userMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TranslateUiState(
    val input: String = "",
    val output: String = "",
    val source: Language,
    val target: Language,
    val isLoading: Boolean = false,
    val message: String? = null,
)

class TranslateViewModel(private val c: AppContainer) : ViewModel() {
    val languages: List<Language> = c.translationEngine.supportedLanguages

    private val _state = MutableStateFlow(
        TranslateUiState(source = languages[0], target = languages[1 % languages.size])
    )
    val state: StateFlow<TranslateUiState> = _state.asStateFlow()

    fun onInput(text: String) = _state.update { it.copy(input = text) }
    fun onSource(l: Language) = _state.update { it.copy(source = l) }
    fun onTarget(l: Language) = _state.update { it.copy(target = l) }
    fun clearInput() = _state.update { it.copy(input = "", output = "") }
    fun dismissMessage() = _state.update { it.copy(message = null) }

    fun swap() = _state.update {
        it.copy(source = it.target, target = it.source, input = it.output, output = it.input)
    }

    fun translate() {
        val s = _state.value
        if (s.input.isBlank()) return
        _state.update { it.copy(isLoading = true) }
        viewModelScope.launch {
            c.translateAndSave(s.input, s.source, s.target).fold(
                onSuccess = { out -> _state.update { it.copy(output = out, isLoading = false) } },
                onFailure = { e -> _state.update { it.copy(isLoading = false, message = e.userMessage()) } },
            )
        }
    }

    fun speak(text: String, language: Language) {
        c.speechEngine.speak(text, language).onFailure { e ->
            _state.update { it.copy(message = e.userMessage()) }
        }
    }
}
