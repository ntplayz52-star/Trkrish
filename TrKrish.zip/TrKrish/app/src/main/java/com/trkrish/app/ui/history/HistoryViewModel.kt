package com.trkrish.app.ui.history

import androidx.lifecycle.ViewModel
import com.trkrish.app.AppContainer
import com.trkrish.app.domain.Language

class HistoryViewModel(private val c: AppContainer) : ViewModel() {
    val items = c.history.items
    fun delete(id: Long) = c.history.delete(id)
    fun clearAll() = c.history.clear()
    fun speak(text: String, language: Language) = c.speechEngine.speak(text, language)
}
