package com.trkrish.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import com.trkrish.app.domain.model.HistoryItem
import com.trkrish.app.domain.repository.HistoryRepository
import kotlinx.coroutines.flow.StateFlow

class HistoryViewModel(private val repository: HistoryRepository) : ViewModel() {
    val items: StateFlow<List<HistoryItem>> = repository.items
    fun delete(id: Long) = repository.delete(id)
    fun clear() = repository.clear()
}
