package com.trkrish.app.data

import com.trkrish.app.domain.HistoryRepository
import com.trkrish.app.domain.TranslationRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/** Keeps history while the app is open. Later we can save it to a database. */
class InMemoryHistoryRepository : HistoryRepository {
    private val _items = MutableStateFlow<List<TranslationRecord>>(emptyList())
    override val items: StateFlow<List<TranslationRecord>> = _items.asStateFlow()

    override fun add(record: TranslationRecord) = _items.update { listOf(record) + it }
    override fun delete(id: Long) = _items.update { list -> list.filterNot { it.id == id } }
    override fun clear() { _items.value = emptyList() }
}
