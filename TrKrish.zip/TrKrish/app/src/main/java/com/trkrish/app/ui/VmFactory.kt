package com.trkrish.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.trkrish.app.AppContainer
import com.trkrish.app.ui.history.HistoryViewModel
import com.trkrish.app.ui.photo.PhotoViewModel
import com.trkrish.app.ui.translate.TranslateViewModel

class VmFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
        TranslateViewModel::class.java -> TranslateViewModel(c)
        PhotoViewModel::class.java -> PhotoViewModel(c)
        HistoryViewModel::class.java -> HistoryViewModel(c)
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    } as T
}
