package com.trkrish.app.ui.photo

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trkrish.app.AppContainer
import com.trkrish.app.domain.Language
import com.trkrish.app.domain.userMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PhotoUiState(
    val imageUri: Uri? = null,
    val extracted: String = "",
    val translated: String = "",
    val source: Language,
    val target: Language,
    val isReading: Boolean = false,
    val isTranslating: Boolean = false,
    val message: String? = null,
)

class PhotoViewModel(private val c: AppContainer) : ViewModel() {
    val languages: List<Language> = c.translationEngine.supportedLanguages

    private val _state = MutableStateFlow(
        PhotoUiState(source = languages[0], target = languages[1 % languages.size])
    )
    val state: StateFlow<PhotoUiState> = _state.asStateFlow()

    fun onSource(l: Language) = _state.update { it.copy(source = l) }
    fun onTarget(l: Language) = _state.update { it.copy(target = l) }
    fun onExtractedEdit(t: String) = _state.update { it.copy(extracted = t) }
    fun dismissMessage() = _state.update { it.copy(message = null) }

    fun swap() = _state.update { it.copy(source = it.target, target = it.source) }

    fun onImagePicked(uri: Uri) {
        _state.update { it.copy(imageUri = uri, extracted = "", translated = "", isReading = true) }
        viewModelScope.launch {
            c.textRecognizer.recognize(uri).fold(
                onSuccess = { t -> _state.update { it.copy(extracted = t, isReading = false) } },
                onFailure = { e -> _state.update { it.copy(isReading = false, message = e.userMessage()) } },
            )
        }
    }

    fun translate() {
        val s = _state.value
        if (s.extracted.isBlank()) return
        _state.update { it.copy(isTranslating = true) }
        viewModelScope.launch {
            c.translateAndSave(s.extracted, s.source, s.target).fold(
                onSuccess = { out -> _state.update { it.copy(translated = out, isTranslating = false) } },
                onFailure = { e -> _state.update { it.copy(isTranslating = false, message = e.userMessage()) } },
            )
        }
    }

    fun speak(text: String, language: Language) {
        c.speechEngine.speak(text, language).onFailure { e ->
            _state.update { it.copy(message = e.userMessage()) }
        }
    }
}
