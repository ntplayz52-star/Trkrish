package com.trkrish.app.domain.model

data class Language(val code: String, val name: String) {
    val isAuto: Boolean get() = code == AUTO_CODE

    companion object {
        const val AUTO_CODE = "auto"
    }
}

object Languages {
    val AutoDetect = Language(Language.AUTO_CODE, "Detect language")
    val English = Language("en", "English")
    val Spanish = Language("es", "Spanish")

    // To add your special language later, add one line to this list.
    val all: List<Language> = listOf(
        English,
        Language("hi", "Hindi"),
        Language("bn", "Bengali"),
        Language("ta", "Tamil"),
        Language("te", "Telugu"),
        Language("mr", "Marathi"),
        Language("gu", "Gujarati"),
        Language("ur", "Urdu"),
        Spanish,
        Language("fr", "French"),
        Language("de", "German"),
        Language("ja", "Japanese"),
        Language("ar", "Arabic"),
    )

    val sourceOptions: List<Language> = listOf(AutoDetect) + all
    val targetOptions: List<Language> = all
}
