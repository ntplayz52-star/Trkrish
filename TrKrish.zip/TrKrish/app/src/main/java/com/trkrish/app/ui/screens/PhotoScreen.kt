package com.trkrish.app.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.trkrish.app.ui.components.EmptyState
import com.trkrish.app.ui.components.ErrorBanner
import com.trkrish.app.ui.components.LanguageBar
import com.trkrish.app.ui.components.LoadingButton
import com.trkrish.app.ui.components.ResultCard
import com.trkrish.app.ui.components.SpeakerButton
import com.trkrish.app.ui.viewmodel.PhotoViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PhotoScreen(viewModel: PhotoViewModel, modifier: Modifier = Modifier) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val bitmap = withContext(Dispatchers.IO) { loadBitmap(context, uri) }
                if (bitmap != null) viewModel.onImagePicked(bitmap)
            }
        }
    }
    val pickImage = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        LanguageBar(
            source = state.source,
            target = state.target,
            onSourceChange = viewModel::setSource,
            onTargetChange = viewModel::setTarget,
            onSwap = viewModel::swapLanguages,
        )

        Card(Modifier.fillMaxWidth()) {
            val image = state.image
            if (image == null) {
                EmptyState(
                    icon = Icons.Filled.PhotoCamera,
                    message = "Choose a photo that contains text",
                    modifier = Modifier.heightIn(min = 180.dp),
                )
            } else {
                Image(
                    bitmap = image.asImageBitmap(),
                    contentDescription = "Selected photo",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp),
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { pickImage() }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.PhotoCamera, contentDescription = null)
                Text("  Choose photo")
            }
        }

        LoadingButton(
            text = "Extract text",
            onClick = viewModel::extractText,
            isLoading = state.isExtracting,
            enabled = state.image != null,
        )

        if (state.extractedText.isNotBlank()) {
            OutlinedTextField(
                value = state.extractedText,
                onValueChange = viewModel::onExtractedTextChange,
                modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                label = { Text("Extracted text (you can edit it)") },
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                SpeakerButton(onClick = { viewModel.speak(state.extractedText, state.source) })
            }
            LoadingButton(
                text = "Translate",
                onClick = viewModel::translate,
                isLoading = state.isTranslating,
            )
        }

        state.error?.let { ErrorBanner(it) }

        if (state.translatedText.isNotBlank()) {
            ResultCard(
                title = state.target.name,
                text = state.translatedText,
                onSpeak = { viewModel.speak(state.translatedText, state.target) },
            )
        }
    }
}

private fun loadBitmap(context: Context, uri: Uri): Bitmap? = try {
    val options = BitmapFactory.Options().apply { inSampleSize = 2 } // half size = less memory
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
} catch (e: Exception) {
    null
}
