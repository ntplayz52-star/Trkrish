package com.trkrish.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF3F51B5), onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E4FF), onPrimaryContainer = Color(0xFF0B1550),
    secondary = Color(0xFF00897B),
    background = Color(0xFFF6F7FD), surface = Color.White,
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFFB6BEFF), onPrimary = Color(0xFF0B1550),
    primaryContainer = Color(0xFF2A3790), onPrimaryContainer = Color(0xFFE0E4FF),
    secondary = Color(0xFF4DB6AC),
    background = Color(0xFF11131A), surface = Color(0xFF1B1E29),
)

@Composable
fun TrKrishTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkColors else LightColors, content = content)
}
