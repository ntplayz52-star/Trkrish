package com.trkrish.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.trkrish.app.domain.engine.Outcome
import com.trkrish.app.domain.engine.SpeechEngine
import com.trkrish.app.domain.engine.TranslationEngine
import com.trkrish.app.domain.model.HistoryItem
import com.trkrish.app.domain.model.Language
import com.trkrish.app.domain.model.Languages
import com.trkrish.app.domain.repository.HistoryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TranslateUiState(
    val source: Language = Languages.English,
    val target: Language = Languages.Spanish,
    val input: String = "",
    val output: String = "",
    val isLoading: Boolean = false,
    val error: String? = null,
)

class TranslateViewModel(
    private val engine: TranslationEngine,
    private val speech: SpeechEngine,
    private val history: HistoryRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(TranslateUiState())
    val state: StateFlow<TranslateUiState> = _state.asStateFlow()

    fun onInputChange(text: String) = _state.update { it.copy(input = text, error = null) }
    fun setSource(language: Language) = _state.update { it.copy(source = language) }
    fun setTarget(language: Language) = _state.update { it.copy(target = language) }

    fun swapLanguages() = _state.update { s ->
        if (s.source.isAuto) s
        else s.copy(
            source = s.target, target = s.source,
            input = s.output, output = s.input, error = null,
        )
    }

    fun translate() {
        val s = _state.value
        if (s.input.isBlank() || s.isLoading) return
        _state.update { it.copy(isLoading = true, error = null) }
        viewModelScope.launch {
            when (val result = engine.translate(s.input.trim(), s.source, s.target)) {
                is Outcome.Success -> {
                    val now = System.currentTimeMillis()
                    history.add(HistoryItem(now, s.input.trim(), result.value, s.source, s.target, now))
                    _state.update { it.copy(isLoading = false, output = result.value) }
                }
                is Outcome.Failure ->
                    _state.update { it.copy(isLoading = false, output = "", error = result.message) }
            }
        }
    }

    fun speak(text: String, language: Language) {
        if (text.isBlank()) return
        val result = speech.speak(text, language)
        if (result is Outcome.Failure) _state.update { it.copy(error = result.message) }
    }

    override fun onCleared() = speech.stop()
}
