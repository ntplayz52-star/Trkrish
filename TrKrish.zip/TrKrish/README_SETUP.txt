Copy the folder  app/src/main/java/com/trkrish/app  over the same folder in your Android Studio project.
Then follow the steps in the chat (dependencies + one line in AndroidManifest.xml).
